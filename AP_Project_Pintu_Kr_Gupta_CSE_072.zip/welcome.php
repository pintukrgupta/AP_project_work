<html>
<body>
	Welcome <?php echo $_GET["fname"]; ?><br>
	your email address is: <?php cho $_GET["email"]; ?>
</body>
</html>